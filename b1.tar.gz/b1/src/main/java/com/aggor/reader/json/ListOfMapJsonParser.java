package com.aggor.reader.json;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

import java.util.List;
import java.util.Map;

/**
 * Created by semenu on 20/06/15.
 */
public class ListOfMapJsonParser {
    private Gson gson;

    public ListOfMapJsonParser(Gson gson) {
        this.gson = gson;
    }

    public List<Map<String, String>> parse(final String json) {
        return gson.fromJson(json, new TypeToken<List<Map<String, String>>>() {}.getType());
    }
}