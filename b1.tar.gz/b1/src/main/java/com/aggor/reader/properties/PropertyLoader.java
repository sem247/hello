package com.aggor.reader.properties;

import java.util.Properties;

public class PropertyLoader {

    private static ConfigLoader[] LOADERS = new ConfigLoader[]{
            new ExternalConfigLoader(),
            new ClasspathConfigLoader()
    };

    public static Properties loadProperties(String file) {
        for (ConfigLoader loader : LOADERS) {
            Properties config = loader.load(file);
            if (config != null) {
                return config;
            }
        }

        throw new RuntimeException("config file not found: " + file);
    }

}