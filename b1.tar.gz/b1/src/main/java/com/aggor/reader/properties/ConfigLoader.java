package com.aggor.reader.properties;

import java.util.Properties;

public interface ConfigLoader {

    Properties load(String file);

}