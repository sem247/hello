package com.aggor.reader.json;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.util.Scanner;

/**
 * Created by semenu on 20/06/15.
 */
public class JsonFileReader {
    private static Logger LOGGER = LoggerFactory.getLogger(JsonFileReader.class);

    public String readFile(String folder, String fileName) {
        if (folder == null || folder.length() == 0) {
            return null;
        }

        File file = new File(folder, fileName);
        if (!file.exists() || file.isDirectory()) {
            return null;
        }

        try {
            return new Scanner(new FileInputStream(file), "UTF-8").useDelimiter("\\A").next();
        } catch (Exception e) {
            LOGGER.error("Unable to read property file: " + file.getAbsolutePath(), e);
        }

        return null;
    }

}