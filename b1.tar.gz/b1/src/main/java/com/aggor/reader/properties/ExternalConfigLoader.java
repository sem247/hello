package com.aggor.reader.properties;

import java.util.Properties;

public class ExternalConfigLoader extends FileConfigLoader {

    @Override
    public Properties load(String file) {
        return loadImpl(System.getProperty("config"), file);
    }

}