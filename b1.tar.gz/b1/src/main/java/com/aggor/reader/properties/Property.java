package com.aggor.reader.properties;

import java.util.Properties;

public class Property {

    private Properties properties;

    public Property(Properties properties) {
        this.properties = properties;
    }

    public String getProperty(String key) {
        String value = System.getProperty(key);

        return value != null ? value : properties.getProperty(key);
    }

}