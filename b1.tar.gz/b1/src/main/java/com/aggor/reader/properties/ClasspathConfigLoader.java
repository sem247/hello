package com.aggor.reader.properties;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Properties;

public class ClasspathConfigLoader implements ConfigLoader {

    @Override
    public Properties load(String file) {
        InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(file);

        if (inputStream == null) {
            return null;
        }

        try {
            try (Reader reader = new InputStreamReader(inputStream, "UTF-8")) {
                Properties properties = new Properties();
                properties.load(reader);
                return properties;
            }
        } catch (Throwable e) {
            throw new RuntimeException("Unable to read property file: " + file, e);
        }
    }

}