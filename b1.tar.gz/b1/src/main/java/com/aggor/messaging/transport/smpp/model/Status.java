package com.aggor.messaging.transport.smpp.model;

/**
 * Created by semenu on 05/07/15.
 */
public enum Status {
    CONNECTED, NOT_CONNECTED
}
