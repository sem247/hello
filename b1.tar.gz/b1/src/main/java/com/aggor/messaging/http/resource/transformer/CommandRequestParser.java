package com.aggor.messaging.http.resource.transformer;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

import java.util.Map;

/**
 * Created by semenu on 21/03/15.
 */
public class CommandRequestParser {
    private Gson gson;

    public CommandRequestParser(Gson gson) {
        this.gson = gson;
    }

    public Map<String, String> parse(final String json) {
        return gson.fromJson(json, new TypeToken<Map<String, String>>() {}.getType());
    }
}
