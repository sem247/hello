package com.aggor.messaging.transport.smpp;

import com.cloudhopper.smpp.SmppBindType;
import com.cloudhopper.smpp.SmppSessionConfiguration;
import com.google.gson.JsonObject;

import java.util.Map;
import java.util.function.Function;

import static java.util.Collections.singletonMap;

/**
 * @author semenu
 *
 */
public class SessionConfigurer implements Function<JsonObject, Map<String, SmppSessionConfiguration>> {
    @Override
    public Map<String, SmppSessionConfiguration> apply(JsonObject configAsJsonObject) {
        SmppSessionConfiguration sessionConfiguration = new SmppSessionConfiguration();

        sessionConfiguration.setWindowSize(configAsJsonObject.get("window_size").getAsInt());
        sessionConfiguration.setName(configAsJsonObject.get("name").getAsString());

        final String bindType = configAsJsonObject.get("bind_type").getAsString();
        sessionConfiguration.setType(SmppBindType.valueOf(bindType.toUpperCase()));

        sessionConfiguration.setHost(configAsJsonObject.get("host").getAsString());

        sessionConfiguration.setPort(configAsJsonObject.get("port").getAsInt());

        sessionConfiguration.setConnectTimeout(configAsJsonObject.get("connect_timeout").getAsInt());

        sessionConfiguration.setSystemId(configAsJsonObject.get("system_id").getAsString());

        sessionConfiguration.setPassword(configAsJsonObject.get("password").getAsString());

        sessionConfiguration.getLoggingOptions().setLogBytes(configAsJsonObject.get("log_bytes").getAsBoolean());

        // to enable monitoring (request expiration)
        sessionConfiguration.setRequestExpiryTimeout(configAsJsonObject.get("request_expiry_timeout").getAsInt());

        sessionConfiguration.setWindowMonitorInterval(configAsJsonObject.get("window_monitor_interval").getAsInt());

        sessionConfiguration.setCountersEnabled(configAsJsonObject.get("enable_counters").getAsBoolean());

        return singletonMap(configAsJsonObject.get("telco").getAsString(), sessionConfiguration);
    }
}