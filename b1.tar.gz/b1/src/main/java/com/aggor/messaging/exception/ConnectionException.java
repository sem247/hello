package com.aggor.messaging.exception;

/**
 * Created by semenu on 07/07/15.
 */
public class ConnectionException extends RuntimeException {
    public ConnectionException(Exception e) {
        super(e);
    }
}