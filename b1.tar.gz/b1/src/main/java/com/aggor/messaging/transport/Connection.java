package com.aggor.messaging.transport;

import com.aggor.messaging.model.ShortMessage;
import com.aggor.messaging.transport.smpp.model.EnqireLinkResult;
import com.aggor.messaging.transport.smpp.model.Status;
import com.cloudhopper.smpp.pdu.SubmitSmResp;

/**
 * @author semenu
 *
 */
public interface Connection {
	
	void connect();

	void disconnect();
	
	EnqireLinkResult enquireLink();

	SubmitSmResp send(ShortMessage shortMessage);

    Status getStatus();

}