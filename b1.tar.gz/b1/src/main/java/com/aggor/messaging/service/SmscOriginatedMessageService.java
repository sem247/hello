package com.aggor.messaging.service;

import com.aggor.messaging.http.client.RouterClient;
import com.aggor.messaging.http.resource.transformer.ServiceBoundMessageTransformer;
import com.cloudhopper.smpp.pdu.DeliverSm;
import org.slf4j.Logger;

import java.time.Instant;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * @author semenu
 *
 */
public class SmscOriginatedMessageService {
    private final Logger logger = getLogger(SmscOriginatedMessageService.class);

    private final RouterClient routerClient;
    private final ServiceBoundMessageTransformer serviceBoundMessageTransformer;

	public SmscOriginatedMessageService(
            RouterClient routerClient,
            ServiceBoundMessageTransformer serviceBoundMessageTransformer
    ) {
        this.routerClient = routerClient;
        this.serviceBoundMessageTransformer = serviceBoundMessageTransformer;
    }

	public void receive(final DeliverSm deliverSm, final String telcoId, final String host, Instant messageDateTime) {
		logger.info(telcoId + "-" + host + "::DeliverSm => ", deliverSm);
		routerClient.postMessage(serviceBoundMessageTransformer.transform(deliverSm, telcoId, messageDateTime));
	}
}