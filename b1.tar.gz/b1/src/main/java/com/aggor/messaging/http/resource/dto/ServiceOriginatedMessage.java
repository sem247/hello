package com.aggor.messaging.http.resource.dto;

import java.util.Set;

/**
 * @author semenu
 *
 */
public class ServiceOriginatedMessage {
	private String messageId;
	private String sender;
	private Set<String> recipients;
	private String content;
	
	public ServiceOriginatedMessage(String messageId, String sender,
			Set<String> recipients, String content) {
		this.messageId = messageId;
		this.sender = sender;
		this.recipients = recipients;
		this.content = content;
	}

	public String getMessageId() {
		return messageId;
	}

	public String getSender() {
		return sender;
	}

	public Set<String> getRecipients() {
		return recipients;
	}

	public String getContent() {
		return content;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((content == null) ? 0 : content.hashCode());
		result = prime * result
				+ ((messageId == null) ? 0 : messageId.hashCode());
		result = prime * result
				+ ((recipients == null) ? 0 : recipients.hashCode());
		result = prime * result + ((sender == null) ? 0 : sender.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		ServiceOriginatedMessage other = (ServiceOriginatedMessage) obj;
		if (content == null) {
			if (other.content != null) {
				return false;
			}
		} else if (!content.equals(other.content)) {
			return false;
		}
		if (messageId == null) {
			if (other.messageId != null) {
				return false;
			}
		} else if (!messageId.equals(other.messageId)) {
			return false;
		}
		if (recipients == null) {
			if (other.recipients != null) {
				return false;
			}
		} else if (!recipients.equals(other.recipients)) {
			return false;
		}
		if (sender == null) {
			if (other.sender != null) {
				return false;
			}
		} else if (!sender.equals(other.sender)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "ServiceOriginatedMessage [messageId=" + messageId + ", sender="
				+ sender + ", recipients=" + recipients + ", content="
				+ content + "]";
	}

}
