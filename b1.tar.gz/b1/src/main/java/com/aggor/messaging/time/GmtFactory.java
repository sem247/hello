package com.aggor.messaging.time;

import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import static com.aggor.messaging.time.TimeZone.GMT;

/**
 * @author semenu
 *
 */
public class GmtFactory {
	private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withZone(GMT);

	public static Instant toInstant(final String time) {
		return formatter.parse(time, ZonedDateTime::from).toInstant();
	}

	public static String fromInstant(final Instant instant) {
		return formatter.format(instant);
	}

}