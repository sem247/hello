package com.aggor.messaging.queueing;

import com.aggor.messaging.model.ShortMessage;
import com.google.gson.Gson;
import org.slf4j.Logger;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.util.List;

import static com.aggor.messaging.queueing.TypeChecker.isNumeric;
import static java.lang.Character.isDigit;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Created by semenu on 06/06/15.
 */
public class MessageConsumerThread {
    private static final Logger LOGGER = getLogger(MessageConsumerThread.class);

    public static void registerConsumer(SmscBoundMessageConsumer smscBoundMessageConsumer, String telco, JedisPool jedisPool, Gson gson) {
        LOGGER.debug("Registering consumer...");
        new Thread() {
            @Override
            public void run() {
                LOGGER.debug("Starting consumer thread...");
                final Jedis jedis = jedisPool.getResource();
                LOGGER.debug("Obtained jedis instance... start waiting for messages...");

                while(true) {
                    LOGGER.debug("Waiting for a message in the queue");
                    final List<String> publicationIds = jedis.blpop(0, "sms." + telco);

                    LOGGER.debug("Got the message for IDs = " + publicationIds);
                    publicationIds.stream().forEach(id -> {
                        if(isNumeric(id)) {
                            final String payload = jedis.get("sms." + id);
                            LOGGER.debug("Message received: " + payload);
                            final ShortMessage shortMessage = gson.fromJson(payload, ShortMessage.class);
                            smscBoundMessageConsumer.process(telco, shortMessage);
                        }
                    });
                }

            }
        }.start();
    }

}