package com.aggor.messaging.supervisor;

import com.xeiam.sundial.JobAction;
import com.xeiam.sundial.exceptions.JobInterruptException;

/**
 * Created by semenu on 19/07/15.
 */
public class EnquireLinkJobAction extends JobAction {

    private SessionManager sessionManager;

    public EnquireLinkJobAction(SessionManager sessionManager) {
        this.sessionManager = sessionManager;
    }

    @Override
    public void doRun() throws JobInterruptException {
        sessionManager.enquireLink();
    }
}
