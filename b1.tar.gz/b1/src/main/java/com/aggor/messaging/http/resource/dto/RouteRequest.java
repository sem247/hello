package com.aggor.messaging.http.resource.dto;

import java.util.Set;

/**
 * Created by semenu on 21/03/15.
 */
public class RouteRequest {
    private String accountId;
    private Set<String> registeredNumbers;

    public RouteRequest(String accountId, Set<String> registeredNumbers) {
        this.accountId = accountId;
        this.registeredNumbers = registeredNumbers;
    }

    public String getAccountId() {
        return accountId;
    }

    public Set<String> getRegisteredNumbers() {
        return registeredNumbers;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RouteRequest that = (RouteRequest) o;

        if (!accountId.equals(that.accountId)) return false;
        if (!registeredNumbers.equals(that.registeredNumbers)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = accountId.hashCode();
        final int prime = 31;
        result = prime * result + registeredNumbers.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "RouteRequest{" +
                "accountId='" + accountId + '\'' +
                ", registeredNumbers=" + registeredNumbers +
                '}';
    }
}
