package com.aggor.messaging.model;

/**
 * Created by semenu on 15/03/15.
 */
public enum Command {
    CONNECT, DISCONNECT, ENQUIRE_LINK
}
