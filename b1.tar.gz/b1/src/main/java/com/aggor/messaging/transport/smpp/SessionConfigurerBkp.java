package com.aggor.messaging.transport.smpp;

import com.cloudhopper.smpp.SmppBindType;
import com.cloudhopper.smpp.SmppSessionConfiguration;

import java.util.List;
import java.util.Map;

import static java.util.function.Function.identity;
import static java.util.stream.Collectors.toMap;

/**
 * @author semenu
 *
 */
public class SessionConfigurerBkp {

	public static Map<String, SmppSessionConfiguration> configure(final List<Map<String, String>> smppSessionProperties) {
		return smppSessionProperties.stream().map(m -> {
            SmppSessionConfiguration sessionConfiguration = new SmppSessionConfiguration();

            final int windowSize = Integer.parseInt(m.get("window_size"));
            sessionConfiguration.setWindowSize(windowSize);

            sessionConfiguration.setName(m.get("name"));

            final String bindType = m.get("bind_type");
            sessionConfiguration.setType(SmppBindType.valueOf(bindType.toUpperCase()));

            sessionConfiguration.setHost(m.get("host"));

            final int port = Integer.parseInt(m.get("port"));
            sessionConfiguration.setPort(port);

            final int connectionTimeout = Integer.parseInt(m.get("connect_timeout"));
            sessionConfiguration.setConnectTimeout(connectionTimeout);

            sessionConfiguration.setSystemId(m.get("system_id"));

            sessionConfiguration.setPassword(m.get("password"));

            final boolean logBytes = Boolean.parseBoolean(m.get("log_bytes"));
            sessionConfiguration.getLoggingOptions().setLogBytes(logBytes);

            // to enable monitoring (request expiration)
            final int requestExpiryTimeout = Integer.parseInt(m.get("request_expiry_timeout"));
            sessionConfiguration.setRequestExpiryTimeout(requestExpiryTimeout);

            final int windowMonitorInterval = Integer.parseInt(m.get("window_monitor_interval"));
            sessionConfiguration.setWindowMonitorInterval(windowMonitorInterval);

            final boolean enableCounters = Boolean.parseBoolean(m.get("enable_counters"));
            sessionConfiguration.setCountersEnabled(enableCounters);

            return sessionConfiguration;
        }).collect(toMap(SmppSessionConfiguration::getHost, identity()));
	}

}