package com.aggor.messaging.transport;

import com.aggor.messaging.exception.ConnectionException;
import com.aggor.messaging.transport.smpp.ClientSessionHandler;
import com.aggor.messaging.transport.smpp.model.ConnectionResponse;
import com.cloudhopper.smpp.SmppSession;
import com.cloudhopper.smpp.SmppSessionConfiguration;
import com.cloudhopper.smpp.impl.DefaultSmppClient;
import com.cloudhopper.smpp.pdu.EnquireLink;
import com.cloudhopper.smpp.pdu.EnquireLinkResp;
import com.cloudhopper.smpp.type.RecoverablePduException;
import com.cloudhopper.smpp.type.SmppChannelException;
import com.cloudhopper.smpp.type.SmppTimeoutException;
import com.cloudhopper.smpp.type.UnrecoverablePduException;
import org.slf4j.Logger;

import java.util.concurrent.Callable;

import static com.aggor.messaging.transport.smpp.model.Status.CONNECTED;
import static com.aggor.messaging.transport.smpp.model.Status.NOT_CONNECTED;
import static com.cloudhopper.smpp.SmppConstants.STATUS_OK;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Created by semenu on 30/06/15.
 */
public class Connector implements Callable<ConnectionResponse> {

    private static Logger LOGGER = getLogger(Connector.class);

    private final Integer connTimeout = 10000;
    private final Integer oneHundred = 100;

    private SmppSessionConfiguration sessionConfiguration;
    private DefaultSmppClient clientBootstrap;
    private ClientSessionHandler sessionHandler;

    public Connector(SmppSessionConfiguration sessionConfiguration, DefaultSmppClient clientBootstrap, ClientSessionHandler sessionHandler) {
        this.sessionConfiguration = sessionConfiguration;
        this.clientBootstrap = clientBootstrap;
        this.sessionHandler = sessionHandler;
    }

    @Override
    public ConnectionResponse call() throws ConnectionException {
        try {
            LOGGER.info("Attempting to bind ..................");
            final SmppSession session = clientBootstrap.bind(sessionConfiguration, sessionHandler);

            Thread.sleep(oneHundred);

            final EnquireLinkResp enquireLinkResp = session.enquireLink(new EnquireLink(), connTimeout);

            Thread.sleep(oneHundred);

            if (STATUS_OK == enquireLinkResp.getCommandStatus()) {
                LOGGER.info("Final pending Requests in Window: {}", session.getSendWindow().getSize());
                LOGGER.info("With windowSize = " + session.getSendWindow().getMaxSize());

                return new ConnectionResponse(of(session), CONNECTED);
            } else {
                session.close();

                return new ConnectionResponse(empty(), NOT_CONNECTED);
            }
        } catch (UnrecoverablePduException | RecoverablePduException | SmppChannelException | InterruptedException | SmppTimeoutException e) {
            LOGGER.error("Error binding ..................", e);
            throw new ConnectionException(e);
        }
    }

}