package com.aggor.messaging.http.client;

import com.google.gson.Gson;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.slf4j.Logger;

import java.util.Map;

import static com.aggor.messaging.http.HeaderFields.CONTENT_TYPE;
import static com.aggor.messaging.http.HeaderValues.APPLICATION_JSON;
import static com.mashape.unirest.http.Unirest.post;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * @author semenu
 *
 */
public class RouterClient {
    private final Logger logger = getLogger(RouterClient.class);

    private String routerBaseUrl;
	private Gson gson;

	public RouterClient(String routerBaseUrl, Gson gson) {
		this.routerBaseUrl = routerBaseUrl;
		this.gson = gson;
	}

	public HttpResponse<String> postMessage(final Map<String, String> mobileOriginatedMessage) {
		logger.info("LOGGER::Black:: mobileOriginatedMessage => ", mobileOriginatedMessage);
		HttpResponse<String> jsonResponse = null;
		try {
			jsonResponse = post(routerBaseUrl + "/api/mo-sms")
			  .header(CONTENT_TYPE, APPLICATION_JSON)
			  .body(gson.toJson(mobileOriginatedMessage))
			  .asString();
		} catch (UnirestException e) {
			logger.error("Failed to post message => ", e);
		}

		return jsonResponse;
	}
}