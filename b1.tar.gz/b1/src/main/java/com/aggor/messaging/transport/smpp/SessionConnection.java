package com.aggor.messaging.transport.smpp;

import com.aggor.messaging.exception.ConnectionException;
import com.aggor.messaging.model.ShortMessage;
import com.aggor.messaging.service.SmscOriginatedMessageService;
import com.aggor.messaging.transport.Connection;
import com.aggor.messaging.transport.Connector;
import com.aggor.messaging.transport.smpp.model.ConnectionResponse;
import com.aggor.messaging.transport.smpp.model.EnqireLinkResult;
import com.aggor.messaging.transport.smpp.model.Status;
import com.cloudhopper.commons.util.windowing.WindowFuture;
import com.cloudhopper.smpp.SmppSessionConfiguration;
import com.cloudhopper.smpp.impl.DefaultSmppClient;
import com.cloudhopper.smpp.pdu.*;
import com.cloudhopper.smpp.type.RecoverablePduException;
import com.cloudhopper.smpp.type.SmppChannelException;
import com.cloudhopper.smpp.type.SmppTimeoutException;
import com.cloudhopper.smpp.type.UnrecoverablePduException;
import com.cloudhopper.smpp.util.SmppSessionUtil;
import com.github.rholder.retry.*;
import com.google.common.base.Predicates;
import com.google.common.eventbus.EventBus;
import org.slf4j.Logger;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.atomic.AtomicInteger;

import static com.aggor.messaging.transport.smpp.model.Status.CONNECTED;
import static com.aggor.messaging.transport.smpp.model.Status.NOT_CONNECTED;
import static com.aggor.messaging.transport.smpp.transform.SmscBoundMessageTransformer.transform;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static java.util.Optional.empty;
import static java.util.concurrent.Executors.newCachedThreadPool;
import static java.util.concurrent.Executors.newScheduledThreadPool;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * @author semenu
 *
 */
public class SessionConnection implements Connection {
	private final Logger logger = getLogger(SessionConnection.class);

    private final String telcoId;
    private final String host;

    private final Integer concurrentSessionsExpected = 1;

    private Boolean connected = FALSE;

    private final Boolean synchronous = TRUE;
    private final Integer connTimeout = 10000;
    private ConnectionResponse response;

    private SmppSessionConfiguration sessionConfiguration;
	private SmscOriginatedMessageService messageService;
	private ThreadPoolExecutor executor;
	private ScheduledThreadPoolExecutor monitorExecutor;
	private DefaultSmppClient clientBootstrap;
    private ClientSessionHandler sessionHandler;

	public SessionConnection(
            final String telcoId,
            final SmppSessionConfiguration sessionConfiguration,
            final SmscOriginatedMessageService messageService
    ) {
        this.telcoId = telcoId;
		this.sessionConfiguration = sessionConfiguration;
        this.messageService = messageService;
        host = sessionConfiguration.getHost();
	}

	@Override
	public void connect() {
        if(connected) {
            logger.info("Already connected, nothing to do... returning");
            return;
        }

        this.executor = (ThreadPoolExecutor) newCachedThreadPool();

        this.monitorExecutor = (ScheduledThreadPoolExecutor) newScheduledThreadPool(1, new ThreadFactory() {
            private AtomicInteger sequence = new AtomicInteger(0);

            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r);
                t.setName("SmppClientSessionWindowMonitorPool-" + sequence.getAndIncrement());
                return t;
            }
        });

        clientBootstrap = new DefaultSmppClient(executor, concurrentSessionsExpected, monitorExecutor);
        sessionHandler = new ClientSessionHandler(
                telcoId,
                sessionConfiguration.getHost(),
                messageService,
                new EventBus()
        );

        final Retryer<ConnectionResponse> retrier = RetryerBuilder.<ConnectionResponse>newBuilder()
                .retryIfExceptionOfType(ConnectionException.class)
                .retryIfRuntimeException()
                .withWaitStrategy(WaitStrategies.exponentialWait(1000, 5, SECONDS))
                .withStopStrategy(StopStrategies.stopAfterAttempt(100))
                .retryIfResult(Predicates.equalTo(new ConnectionResponse(empty(), NOT_CONNECTED)))
                .build();

        try {
            response = retrier.call(new Connector(sessionConfiguration, clientBootstrap, sessionHandler));
        } catch (RetryException | ExecutionException e) {
            logger.error("Retry failed...", e);
        }

        connected = CONNECTED.equals(response.getStatus());
    }

	@Override
	public void disconnect() {
        logger.info("Unbinding if we are connected... connection status: " + (connected ? "CONNECTED" :"NOT CONNECTED"));
        if (response.getSession().isPresent()) {
            logger.info("Inside disconnect... session is present -> " + response.getSession().get().getStateName());
        } else {
            logger.info("Inside disconnect... session not present");
        }
        response.getSession().ifPresent(s -> {
            logger.debug("Inside disconnect... calling unbind on session");
            s.unbind(connTimeout);
            logger.debug("Inside disconnect... closing the session");
            SmppSessionUtil.close(s);
        });
        logger.debug("Inside disconnect... destroy the bootstrap");
        clientBootstrap.destroy();
        executor.shutdownNow();
        monitorExecutor.shutdownNow();
        connected = FALSE;
        logger.info("Done. Exiting");
    }

	@SuppressWarnings("rawtypes")
	@Override
	public EnqireLinkResult enquireLink() {
        response.getSession().map(s -> {
            try {
                final WindowFuture<Integer, PduRequest, PduResponse> future = s.sendRequestPdu(new EnquireLink(), connTimeout, synchronous);
                if (!future.await()) {
                    logger.warn(telcoId + "-" + host + "::Failed to receive enquire_link_resp within specified time");
                } else if (future.isSuccess()) {
                    final EnquireLinkResp enquireLinkResp = (EnquireLinkResp) future.getResponse();
                    logger.info(telcoId + "-" + host + "::enquire_link_resp #2: commandStatus ["
                            + enquireLinkResp.getCommandStatus() + "="
                            + enquireLinkResp.getResultMessage() + "]");
                } else {
                    logger.warn(telcoId + "-" + host + "::Failed to properly receive enquire_link_resp: " + future.getCause());
                }
            } catch (InterruptedException | RecoverablePduException
                    | UnrecoverablePduException | SmppTimeoutException
                    | SmppChannelException e) {
                logger.error(telcoId + "-" + host, e);
            }

            return null;
        });

        return null;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public SubmitSmResp send(ShortMessage shortMessage) {
        final int sendTimeout = 30000;
        response.getSession().map(s -> {
            try {
                final SubmitSm submit = transform(shortMessage);

                final WindowFuture<Integer, PduRequest, PduResponse> future = s.sendRequestPdu(submit, sendTimeout, synchronous);

                if (!future.await()) {
                    logger.error("Failed to receive submit_sm_resp within specified time");
                } else if (future.isSuccess()) {
                    final SubmitSmResp submitSmResp = (SubmitSmResp) future.getResponse();
                    logger.info("submit_sm_resp #2: commandStatus ["
                            + submitSmResp.getCommandStatus() + "="
                            + submitSmResp.getResultMessage() + "]");
                } else {
                    logger.error("Failed to properly receive submit_sm_resp: " + future.getCause());
                }
            } catch (RecoverablePduException | UnrecoverablePduException
                    | SmppTimeoutException | SmppChannelException | InterruptedException e) {
                logger.error("", e);
            }

            return null;
        });

        return null;
	}

    @Override
    public Status getStatus() {
        return connected ? CONNECTED : NOT_CONNECTED;
    }

}