package com.aggor.messaging.supervisor;

import com.xeiam.sundial.Job;
import com.xeiam.sundial.annotations.SimpleTrigger;
import com.xeiam.sundial.exceptions.JobInterruptException;

import static java.util.concurrent.TimeUnit.SECONDS;

/**
 * Created by semenu on 21/07/15.
 */
@SimpleTrigger(repeatInterval = 20, timeUnit = SECONDS)
public class EnquireLinkJob extends Job {
    @Override
    public void doRun() throws JobInterruptException {
        
    }
}
