package com.aggor.messaging.queueing;

import com.aggor.messaging.model.ShortMessage;
import com.aggor.messaging.supervisor.SessionManager;

/**
 * @author semenu
 *
 */
public class SmscBoundMessageConsumer {
    private final SessionManager sessionManager;

    public SmscBoundMessageConsumer(SessionManager sessionManager) {
        this.sessionManager = sessionManager;
    }

    public void process(String telco, ShortMessage shortMessage) {
        sessionManager.send(telco, shortMessage);
    }
}