package com.aggor.messaging.http.resource.handler;

import com.aggor.messaging.model.ShortMessage;

/**
 * Created by semenu on 09/06/16.
 */
public class PostHandler {
    public Object terminateAtMobile(String body) {
        final ShortMessage shortMessage = gson.fromJson(payload, ShortMessage.class);
        smscBoundMessageConsumer.process(telco, shortMessage);

        return null;
    }
}
