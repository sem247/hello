package com.aggor.messaging.http.resource.dto;

import com.aggor.messaging.model.ShortMessage;

/**
 * @author semenu
 *
 */
public class MobileOriginatedMessage {
	private String smscId;
	private ShortMessage shortMessage;
    private String messageDateTime;
	
	public MobileOriginatedMessage(final String smscId, final ShortMessage shortMessage, String messageDateTime) {
		this.smscId = smscId;
		this.shortMessage = shortMessage;
        this.messageDateTime = messageDateTime;
    }

	public String getSmscId() {
		return smscId;
	}

	public ShortMessage getShortMessage() {
		return shortMessage;
	}

    public String getMessageDateTime() {
        return messageDateTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MobileOriginatedMessage that = (MobileOriginatedMessage) o;

        if (!messageDateTime.equals(that.messageDateTime)) return false;
        if (!shortMessage.equals(that.shortMessage)) return false;
        if (!smscId.equals(that.smscId)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = smscId.hashCode();
        final int prime = 31;
        result = prime * result + shortMessage.hashCode();
        result = prime * result + messageDateTime.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "IncomingMessage{" +
                "smscId='" + smscId + '\'' +
                ", shortMessage=" + shortMessage +
                ", messageDateTime='" + messageDateTime + '\'' +
                '}';
    }
}
