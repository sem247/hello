package com.aggor.messaging.model;

import java.time.Instant;
import java.util.Optional;
import java.util.Set;

/**
 * @author semenu
 *
 */
public class GenericMessage {
	private String accountId;
	private Optional<Integer> messageId;
	private String sender;
	private Set<String> recipients;
	private Optional<String> content;
    private Instant messageDateTime;

	public GenericMessage(
            String accountId,
            Optional<Integer> messageId,
            String sender,
            Set<String> recipients,
            Optional<String> content,
            Instant messageDateTime
    ) {
		this.accountId = accountId;
		this.messageId = messageId;
		this.sender = sender;
		this.recipients = recipients;
		this.content = content;
        this.messageDateTime = messageDateTime;
	}

	public String getAccountId() {
		return accountId;
	}

	public Optional<Integer> getMessageId() {
		return messageId;
	}

	public String getSender() {
		return sender;
	}

	public Set<String> getRecipients() {
		return recipients;
	}

	public Optional<String> getContent() {
		return content;
	}

	public Instant getMessageDateTime() {
		return messageDateTime;
	}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        GenericMessage message = (GenericMessage) o;

        if (!accountId.equals(message.accountId)) return false;
        if (!content.equals(message.content)) return false;
        if (!messageDateTime.equals(message.messageDateTime)) return false;
        if (!messageId.equals(message.messageId)) return false;
        if (!recipients.equals(message.recipients)) return false;
        if (!sender.equals(message.sender)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = accountId.hashCode();
        final int prime = 31;
        result = prime * result + messageId.hashCode();
        result = prime * result + sender.hashCode();
        result = prime * result + recipients.hashCode();
        result = prime * result + content.hashCode();
        result = prime * result + messageDateTime.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "GenericMessage{" +
                "accountId='" + accountId + '\'' +
                ", messageId=" + messageId +
                ", sender='" + sender + '\'' +
                ", recipients=" + recipients +
                ", content=" + content +
                ", messageDateTime=" + messageDateTime +
                '}';
    }
}