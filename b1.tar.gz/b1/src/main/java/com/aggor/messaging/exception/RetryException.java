package com.aggor.messaging.exception;

/**
 * Created by semenu on 30/06/15.
 */
public class RetryException extends RuntimeException {

    public RetryException(String s, Exception e) {

    }
}
