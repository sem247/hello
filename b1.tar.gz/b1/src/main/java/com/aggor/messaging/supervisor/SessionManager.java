package com.aggor.messaging.supervisor;

import com.aggor.messaging.model.ShortMessage;
import com.aggor.messaging.service.SmscOriginatedMessageService;
import com.aggor.messaging.transport.smpp.SessionConnection;
import com.cloudhopper.smpp.SmppSessionConfiguration;
import com.google.common.eventbus.Subscribe;

import java.util.HashMap;
import java.util.Map;

import static com.aggor.messaging.transport.smpp.model.Status.CONNECTED;

/**
 * Created by semenu on 21/06/15.
 */
public class SessionManager {
    private Map<String, SessionConnection> sessionConnections = new HashMap<>();

    public SessionManager(
            final Map<String, SmppSessionConfiguration> sessionConfigurations,
            final SmscOriginatedMessageService messageService
    ) {
        sessionConfigurations.entrySet().forEach(sc -> {
            final String telco = sc.getKey();
            final SessionConnection connection = new SessionConnection(telco, sc.getValue(), messageService);
            this.sessionConnections.put(telco, connection);
        });
    }

    public void connect(String telco) {
        final SessionConnection connection = sessionConnections.get(telco);
        connection.connect();
    }

    public void disconnect(String telco) {
        final SessionConnection connection = sessionConnections.get(telco);
        connection.disconnect();
    }

    public void connect() {
        sessionConnections.entrySet().forEach(s -> s.getValue().connect());
    }

    public void disconnect() {
        sessionConnections.entrySet().forEach(s -> s.getValue().disconnect());
    }

    public void enquireLink() {
        sessionConnections.entrySet().stream()
                .filter(c -> CONNECTED.equals(c.getValue().getStatus()))
                .forEach(s -> s.getValue().enquireLink());
    }

    public void send(String telco, ShortMessage shortMessage) {
        final SessionConnection sessionConnection = sessionConnections.get(telco);
        sessionConnection.send(shortMessage);
    }

    @Subscribe
    public void reconnect(String telco) {
        disconnect(telco);
        connect(telco);
    }
}