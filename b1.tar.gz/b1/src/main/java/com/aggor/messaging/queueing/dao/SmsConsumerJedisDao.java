package com.aggor.messaging.queueing.dao;

import com.aggor.messaging.model.ShortMessage;
import com.aggor.messaging.queueing.SmscBoundMessageConsumer;
import com.google.gson.Gson;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.util.List;

/**
 * Created by semenu on 21/03/15.
 */
public class SmsConsumerJedisDao {
    private SmscBoundMessageConsumer smscBoundMessageConsumer;
    private JedisPool jedisPool;
    private Gson gson;

    public SmsConsumerJedisDao(SmscBoundMessageConsumer smscBoundMessageConsumer, final String smscId, JedisPool jedisPool, Gson gson) {
        this.smscBoundMessageConsumer = smscBoundMessageConsumer;
        this.jedisPool = jedisPool;
        this.gson = gson;

        listen(smscId);
    }

    private void listen(final String key) {
        Jedis jedis = jedisPool.getResource();

        final List<String> publicationIds = jedis.blpop("sms." + key);

//        publicationIds.stream().forEach(id -> {
//            final String message = jedis.get("sms." + id);
//            final ShortMessage shortMessage = gson.fromJson(message, ShortMessage.class);
//            smscBoundMessageConsumer.process(telco, shortMessage);
//        });

        jedisPool.returnResource(jedis);
    }

}