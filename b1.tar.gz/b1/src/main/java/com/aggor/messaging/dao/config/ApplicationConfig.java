package com.aggor.messaging.dao.config;

import com.aggor.messaging.dao.SmsResourceDao;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.annotation.Resource;

/**
 * Created by semenu on 01/05/16.
 */
@Configuration
@EnableTransactionManagement
public class ApplicationConfig {
    @Resource
    private JdbcTemplate jdbcTemplate;

    @Bean
    public SmsResourceDao smsResourceDao() {
        return new SmsResourceDao(jdbcTemplate);
    }

}
