package com.aggor.messaging.time;

import java.time.ZoneId;

/**
 * @author semenu
 *
 */
public interface TimeZone {
	ZoneId GMT = ZoneId.of("GMT");
}