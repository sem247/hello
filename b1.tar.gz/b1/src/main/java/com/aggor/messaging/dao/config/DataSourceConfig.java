package com.aggor.messaging.dao.config;

import org.apache.commons.dbcp2.*;
import org.apache.commons.pool2.ObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.Properties;

import static com.aggor.reader.properties.PropertyLoader.loadProperties;

/**
 * Created by semenu on 01/05/16.
 */
@Configuration
@EnableTransactionManagement
public class DataSourceConfig {

    @Bean
    public DataSource dataSource() {
        Properties properties = buildProperties();

        final ConnectionFactory connectionFactory = new DriverManagerConnectionFactory(
                properties.getProperty("datasource.url"),
                properties
        );
        PoolableConnectionFactory poolableConnectionFactory = new PoolableConnectionFactory(connectionFactory, null);
        final ObjectPool<PoolableConnection> connectionPool = new GenericObjectPool<>(poolableConnectionFactory);
        poolableConnectionFactory.setPool(connectionPool);

        return new PoolingDataSource<>(connectionPool);
    }

    @Bean
    public JdbcTemplate jdbcTemplate() {
        return new JdbcTemplate(dataSource());
    }

    @Bean
    public DataSourceTransactionManager transactionManager() {
        return new DataSourceTransactionManager(dataSource());
    }

    private Properties buildProperties() {
        final Properties properties = loadProperties("db.properties");

        //        p.setUrl(properties.getProperty("datasource.url"));
//        p.setDriverClassName(properties.getProperty("datasource.drivers"));
//        p.setUsername(properties.getProperty("datasource.user"));
//        p.setPassword(properties.getProperty("datasource.password"));
//
//        final String testWhileIdle = properties.getProperty("datasource.testWhileIdle");
//        if(testWhileIdle != null) {
//            p.setTestWhileIdle(Boolean.parseBoolean(testWhileIdle));
//        }
//        final String testOnBorrow = properties.getProperty("datasource.testOnBorrow");
//        if(testOnBorrow != null) {
//            p.setTestOnBorrow(Boolean.parseBoolean(testOnBorrow));
//        }
//        final String validationQuery = properties.getProperty("datasource.validation_query");
//        if(validationQuery != null) {
//            p.setValidationQuery(validationQuery);
//        }
//        final String testOnReturn = properties.getProperty("datasource.testOnReturn");
//        if(testOnReturn != null) {
//            p.setTestOnReturn(Boolean.parseBoolean(testOnReturn));
//        }
//        final String validationInterval = properties.getProperty("datasource.validationInterval");
//        if(validationInterval != null) {
//            p.setValidationInterval(Integer.parseInt(validationInterval));
//        }
//        final String timeBetweenEvictionRunsMillis = properties.getProperty("datasource.timeBetweenEvictionRunsMillis");
//        if(timeBetweenEvictionRunsMillis != null) {
//            p.setTimeBetweenEvictionRunsMillis(Integer.parseInt(timeBetweenEvictionRunsMillis));
//        }
//        final String maxActiveConnections = properties.getProperty("datasource.maxActive.connections");
//        if(maxActiveConnections != null) {
//            p.setMaxActive(Integer.parseInt(maxActiveConnections));
//        }
//        final String initialSize = properties.getProperty("datasource.initialSize");
//        if(initialSize != null) {
//            p.setInitialSize(Integer.parseInt(initialSize));
//        }
//        final String maxWaitConnections = properties.getProperty("datasource.maxWait.connections");
//        if(maxWaitConnections != null) {
//            p.setMaxWait(Integer.parseInt(maxWaitConnections));
//        }
//        final String removeAbandonedTimeout = properties.getProperty("datasource.removeAbandonedTimeout");
//        if(removeAbandonedTimeout != null) {
//            p.setRemoveAbandonedTimeout(60);
//        }
//        final String minEvictableIdleTimeMillis = properties.getProperty("datasource.minEvictableIdleTimeMillis");
//        if(minEvictableIdleTimeMillis != null) {
//            p.setMinEvictableIdleTimeMillis(Integer.parseInt(minEvictableIdleTimeMillis));
//        }
//        final String minIdle = properties.getProperty("datasource.minIdle");
//        if(minIdle != null) {
//            p.setMinIdle(Integer.parseInt(minIdle));
//        }
//        final String logAbandoned = properties.getProperty("datasource.logAbandoned");
//        if(logAbandoned != null) {
//            p.setLogAbandoned(Boolean.parseBoolean(logAbandoned));
//        }
//        final String removeAbanadoned = properties.getProperty("datasource.removeAbanadoned");
//        if(removeAbanadoned != null) {
//            p.setRemoveAbandoned(Boolean.parseBoolean(removeAbanadoned));
//        }
//        final String defaultAutoCommit = properties.getProperty("datasource.defaultAutoCommit");
//        if(defaultAutoCommit != null) {
//            p.setDefaultAutoCommit(Boolean.parseBoolean(defaultAutoCommit));
//        }
//        final String maxIdle = properties.getProperty("datasource.maxIdle");
//        if(maxIdle != null) {
//            p.setMaxIdle(Integer.parseInt(maxIdle));
//        }
//        final String testOnConnect = properties.getProperty("datasource.testOnConnect");
//        if(testOnConnect != null) {
//            p.setTestOnConnect(Boolean.parseBoolean(testOnConnect));
//        }

        return properties;
    }
}