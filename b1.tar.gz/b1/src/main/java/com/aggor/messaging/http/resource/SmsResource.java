package com.aggor.messaging.http.resource;

import com.aggor.messaging.http.resource.handler.PostHandler;
import org.apache.http.entity.ContentType;

import static org.apache.http.entity.ContentType.APPLICATION_JSON;
import static spark.Spark.post;

/**
 * Created by semenu on 09/06/16.
 */
public class SmsResource {
    private final PostHandler postHandler;

    public SmsResource(PostHandler postHandler) {
        this.postHandler = postHandler;

        dispatch();
    }

    private void dispatch() {
        post("api/gateway/terminate_at_mobile", APPLICATION_JSON.getMimeType(), (req, res) -> {

            res.status(202);

            return postHandler.terminateAtMobile(req.body());
        });
    }

}
