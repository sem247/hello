package com.aggor.messaging.transport.smpp.transform;

import com.aggor.messaging.model.ShortMessage;
import com.cloudhopper.smpp.pdu.SubmitSm;
import com.cloudhopper.smpp.type.Address;
import com.cloudhopper.smpp.type.SmppInvalidArgumentException;

import static com.cloudhopper.commons.charset.CharsetUtil.CHARSET_UCS_2;
import static com.cloudhopper.commons.charset.CharsetUtil.encode;

/**
 * @author semenu
 *
 */
public class SmscBoundMessageTransformer {

	public static SubmitSm transform(ShortMessage shortMessage) throws SmppInvalidArgumentException {
        final byte ton = (byte)0x00;
        final byte npi = (byte)0x00;

		SubmitSm submit = new SubmitSm();
		submit.setSourceAddress(new Address(ton, npi, shortMessage.getSender()));
		submit.setDestAddress(new Address(ton, npi, shortMessage.getRecipient()));
		submit.setShortMessage(encode(shortMessage.getMessage(), CHARSET_UCS_2));
		
		return submit;
	}
}
