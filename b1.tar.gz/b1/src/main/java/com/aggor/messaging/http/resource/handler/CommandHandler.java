package com.aggor.messaging.http.resource.handler;

import com.aggor.messaging.model.Command;
import com.aggor.messaging.service.CommandService;

import java.util.List;
import java.util.Map;

import static java.util.Collections.emptyList;

/**
 * Created by semenu on 15/03/15.
 */
public class CommandHandler {
    private CommandService commandService;

    public CommandHandler(CommandService commandService) {
        this.commandService = commandService;
    }

    public List<String> handle(Map<String, String> request) {
        final Command command = Command.valueOf(request.get("command"));

        commandService.perform(command);

        return emptyList();
    }
}