package com.aggor.messaging.http.resource.transformer;

import com.aggor.messaging.model.GenericMessage;

import java.time.Instant;

import static java.util.Collections.emptyList;
import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;

/**
 * @author semenu
 *
 */
public class GenericMessageBuilder {
	public static GenericMessage convert(final String clientId, final ShortMessage shortMessage,
										 final Instant messageDateTime) {
		return new GenericMessage(clientId,
				empty(),
				shortMessage.getSender(),
				shortMessage.getRecipients(),
				ofNullable(shortMessage.getBody()),
                SERVICE_ORIGINATED,
                messageDateTime,
				emptyList()
		);
	}
}