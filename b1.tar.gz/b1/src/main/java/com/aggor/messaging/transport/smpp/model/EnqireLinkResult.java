package com.aggor.messaging.transport.smpp.model;

/**
 * Created by semenu on 22/06/15.
 */
public class EnqireLinkResult {
}
