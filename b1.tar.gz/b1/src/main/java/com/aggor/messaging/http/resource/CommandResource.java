package com.aggor.messaging.http.resource;

import com.aggor.messaging.http.json.JsonTransformer;
import com.aggor.messaging.http.resource.handler.CommandHandler;
import com.aggor.messaging.http.resource.transformer.CommandRequestParser;
import org.apache.http.entity.ContentType;

import static spark.Spark.after;
import static spark.Spark.post;

/**
 * Created by semenu on 15/03/15.
 */
public class CommandResource {
    private JsonTransformer jsonTransformer;
    private CommandHandler commandHandler;
    private CommandRequestParser requestParser;

    public CommandResource(JsonTransformer jsonTransformer, CommandHandler commandHandler, CommandRequestParser requestParser) {
        this.jsonTransformer = jsonTransformer;
        this.commandHandler = commandHandler;
        this.requestParser = requestParser;
        dispatch();
    }

    private void dispatch() {
        after((request, response) -> response.type(ContentType.APPLICATION_JSON.getMimeType()));

        connect();
    }

    public void connect() {
        post("/api/gateway/control", ContentType.APPLICATION_JSON.getMimeType(), (request, response) -> {
            response.status(202);

            return commandHandler.handle(requestParser.parse(request.body()));
        }, jsonTransformer);
    }
}