package com.aggor.messaging.http.resource.transformer;

import com.aggor.messaging.time.GmtFactory;
import com.cloudhopper.smpp.pdu.DeliverSm;
import com.google.common.collect.ImmutableMap;
import org.slf4j.Logger;

import java.time.Instant;
import java.util.Map;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * Created by semenu on 21/03/15.
 */
public class ServiceBoundMessageTransformer {
    private final Logger logger = getLogger(ServiceBoundMessageTransformer.class);

    public Map<String, String> transform(final DeliverSm deliverSm, String smscId, Instant messageDateTime) {
        logger.info("Black::ServiceBoundMessageTransformer#transform -> DeliverSM => ", deliverSm);
        logger.info("sender", deliverSm.getSourceAddress().getAddress());
        logger.info("recipient", deliverSm.getDestAddress().getAddress());
        logger.info("message", new String(deliverSm.getShortMessage()));
        logger.info("smsc", smscId);
        logger.info("messageTime", GmtFactory.fromInstant(messageDateTime));

        return new ImmutableMap.Builder<String, String>()
                .put("sender", deliverSm.getSourceAddress().getAddress())
                .put("recipient", deliverSm.getDestAddress().getAddress())
                .put("message", new String(deliverSm.getShortMessage()))
                .put("smsc", smscId)
                .put("messageTime", GmtFactory.fromInstant(messageDateTime))
                .build();
    }
}