package com.aggor.messaging.service;

import com.aggor.messaging.model.Command;
import com.aggor.messaging.supervisor.SessionManager;

import static com.aggor.messaging.model.Command.CONNECT;
import static com.aggor.messaging.model.Command.DISCONNECT;
import static com.aggor.messaging.model.Command.ENQUIRE_LINK;

/**
 * Created by semenu on 22/03/15.
 */
public class CommandService {
    private final SessionManager sessionManager;

    public CommandService(SessionManager sessionManager) {
        this.sessionManager = sessionManager;
    }

    public void perform(Command command) {

        if(CONNECT.equals(command)) {
            sessionManager.connect();
        }
        if(DISCONNECT.equals(command)) {
            sessionManager.disconnect();
        }
        if(ENQUIRE_LINK.equals(command)) {
            sessionManager.enquireLink();
        }

    }
}