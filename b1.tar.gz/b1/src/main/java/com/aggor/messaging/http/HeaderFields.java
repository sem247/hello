package com.aggor.messaging.http;

/**
 * @author semenu
 *
 */
public interface HeaderFields {
	
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String ACCEPT = "Accept";

}
