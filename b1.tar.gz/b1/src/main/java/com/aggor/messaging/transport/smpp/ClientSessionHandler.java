package com.aggor.messaging.transport.smpp;

import com.aggor.messaging.service.SmscOriginatedMessageService;
import com.cloudhopper.smpp.impl.DefaultSmppSessionHandler;
import com.cloudhopper.smpp.pdu.DeliverSm;
import com.cloudhopper.smpp.pdu.DeliverSmResp;
import com.cloudhopper.smpp.pdu.PduRequest;
import com.cloudhopper.smpp.pdu.PduResponse;
import com.cloudhopper.smpp.type.UnrecoverablePduException;
import com.google.common.eventbus.EventBus;
import org.slf4j.Logger;

import static com.aggor.messaging.time.TimeZone.GMT;
import static com.cloudhopper.smpp.SmppConstants.STATUS_UNKNOWNERR;
import static java.time.ZonedDateTime.now;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * @author semenu
 *
 */
public class ClientSessionHandler extends DefaultSmppSessionHandler {
	private final Logger logger = getLogger(ClientSessionHandler.class);

    private final String telcoId;
    private final String host;
	private final SmscOriginatedMessageService messageService;
	private final EventBus eventBus;

	public ClientSessionHandler(
			final String telcoId,
			final String host,
			final SmscOriginatedMessageService messageService,
			final EventBus eventBus
	) {
		this.telcoId = telcoId;
		this.host = host;
		this.messageService = messageService;
		this.eventBus = eventBus;
	}

	/* (non-Javadoc)
	 * @see com.cloudhopper.smpp.impl.DefaultSmppSessionHandler#firePduRequestReceived(com.cloudhopper.smpp.pdu.PduRequest)
	 */
	@Override
	public PduResponse firePduRequestReceived(PduRequest request) {
		PduResponse response;
		try {
            logger.info("Pre instance check -> PDU => ", request);
			if (request instanceof DeliverSm) {
                logger.info("Post instance check -> PDU => ", request);
				new Thread() {
					@Override
					public void run() {
                        logger.info("inside thread run -> PDU => ", request);
						messageService.receive(
								(DeliverSm) request,
								telcoId,
								host,
								now(GMT).toInstant()
						);
					}
				}.start();

				response = new DeliverSmResp();
			} else {
				response = request.createResponse();
			}
		} catch (Throwable e) {
			logger.error("We received transform request from SMSC [" + telcoId + "-" + host + "], but an error occurred => ", e);
			response = request.createResponse();
			response.setResultMessage(e.getMessage());
			response.setCommandStatus(STATUS_UNKNOWNERR);
		}

		return response;
	}

	/* (non-Javadoc)
	 * @see com.cloudhopper.smpp.impl.DefaultSmppSessionHandler#fireChannelUnexpectedlyClosed()
	 */
	@Override
	public void fireChannelUnexpectedlyClosed() {
		logger.warn("Channel unexpectedly closed.  Will attempt to bring back up.");
		super.fireChannelUnexpectedlyClosed();

        eventBus.post(host);
	}

	/* (non-Javadoc)
	 * @see com.cloudhopper.smpp.impl.DefaultSmppSessionHandler#fireUnrecoverablePduException(com.cloudhopper.smpp.type.UnrecoverablePduException)
	 */
	@Override
	public void fireUnrecoverablePduException(UnrecoverablePduException e) {
		// TODO Auto-generated method stub
		super.fireUnrecoverablePduException(e);
	}

	/* (non-Javadoc)
	 * @see com.cloudhopper.smpp.impl.DefaultSmppSessionHandler#fireUnknownThrowable(java.lang.Throwable)
	 */
	@Override
	public void fireUnknownThrowable(Throwable t) {
		// TODO Auto-generated method stub
		super.fireUnknownThrowable(t);
	}
}