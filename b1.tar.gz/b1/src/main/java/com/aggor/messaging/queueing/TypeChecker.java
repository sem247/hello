package com.aggor.messaging.queueing;

import static java.lang.Character.isDigit;

/**
 * Created by semenu on 12/07/15.
 */
public class TypeChecker {

    public static boolean isNumeric(CharSequence id) {
        if (id == null || id.length() <= 0) {
            return false;
        }
        final int sz = id.length();
        for (int i = 0; i < sz; i++) {
            if (!isDigit(id.charAt(i))) {
                return false;
            }
        }

        return true;
    }

}