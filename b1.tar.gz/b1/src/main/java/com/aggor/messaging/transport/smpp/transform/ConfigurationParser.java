package com.aggor.messaging.transport.smpp.transform;

import com.aggor.messaging.transport.smpp.SessionConfigurer;
import com.aggor.reader.json.JsonFileReader;
import com.cloudhopper.smpp.SmppSessionConfiguration;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiFunction;

/**
 * Created by semenu on 06/06/16.
 */
public class ConfigurationParser implements BiFunction<String, String, Map<String, SmppSessionConfiguration>> {
    private final JsonFileReader jsonFileReader;
    private final JsonParser jsonParser;
    private final SessionConfigurer sessionConfigurer;

    public ConfigurationParser(
            JsonFileReader jsonFileReader,
            JsonParser jsonParser,
            SessionConfigurer sessionConfigurer
    ) {
        this.jsonFileReader = jsonFileReader;
        this.jsonParser = jsonParser;
        this.sessionConfigurer = sessionConfigurer;
    }

    @Override
    public Map<String, SmppSessionConfiguration> apply(String path, String fileName) {
        Map<String, SmppSessionConfiguration> smppSessionConfigurations = new HashMap<>();

        final String connectionsSettings = jsonFileReader.readFile(path, fileName);

        final JsonArray configAsJsonArray = jsonParser.parse(connectionsSettings).getAsJsonArray();

        configAsJsonArray.forEach(c -> smppSessionConfigurations.putAll(sessionConfigurer.apply(c.getAsJsonObject())));

        return smppSessionConfigurations;
    }
}