package com.aggor.messaging;

import com.aggor.messaging.http.client.RouterClient;
import com.aggor.messaging.http.json.JsonTransformer;
import com.aggor.messaging.http.resource.CommandResource;
import com.aggor.messaging.http.resource.handler.CommandHandler;
import com.aggor.messaging.http.resource.transformer.CommandRequestParser;
import com.aggor.messaging.http.resource.transformer.ServiceBoundMessageTransformer;
import com.aggor.messaging.queueing.MessageConsumerThread;
import com.aggor.messaging.queueing.SmscBoundMessageConsumer;
import com.aggor.messaging.service.CommandService;
import com.aggor.messaging.service.SmscOriginatedMessageService;
import com.aggor.messaging.supervisor.SessionManager;
import com.aggor.messaging.transport.smpp.SessionConfigurer;
import com.aggor.messaging.transport.smpp.transform.ConfigurationParser;
import com.aggor.reader.json.JsonFileReader;
import com.cloudhopper.smpp.SmppSessionConfiguration;
import com.google.gson.Gson;
import com.google.gson.JsonParser;
import com.mashape.unirest.http.Unirest;
import org.slf4j.Logger;
import redis.clients.jedis.JedisPool;
import spark.servlet.SparkApplication;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import static com.aggor.reader.properties.PropertyLoader.loadProperties;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * @author semenu
 *
 */
public class Bootstrap implements SparkApplication {
    private final Logger logger = getLogger(Bootstrap.class);

	public static void main(String[] args) {
		new Bootstrap().init();
	}

    @Override
    public void init() {
        final Properties applicationProperties = loadProperties("application.properties");

        final JedisPool jedisPool = new JedisPool(applicationProperties.getProperty("redisbox.url"));

        JsonTransformer jsonTransformer = new JsonTransformer(new Gson());
        final JsonParser jsonParser = new JsonParser();
        final JsonFileReader jsonFileReader = new JsonFileReader();

        final RouterClient routerClient = new RouterClient(
                applicationProperties.getProperty("routerbox.url"),
                jsonTransformer.getGson()
        );

        final SmscOriginatedMessageService smscOriginatedMessageService = new SmscOriginatedMessageService(
                routerClient,
                new ServiceBoundMessageTransformer()
        );

        final ConfigurationParser configurationParser = new ConfigurationParser(
                jsonFileReader,
                jsonParser,
                new SessionConfigurer()
        );

        final Map<String, SmppSessionConfiguration> sessionConfigurations = configurationParser.apply(
                applicationProperties.getProperty("config.path"),
                "connections.json"
        );

        final SessionManager sessionManager = new SessionManager(
                sessionConfigurations,
                smscOriginatedMessageService
        );

        final CommandService commandService = new CommandService(sessionManager);

        final CommandHandler commandHandler = new CommandHandler(commandService);

        final CommandRequestParser commandRequestParser = new CommandRequestParser(jsonTransformer.getGson());

        new CommandResource(jsonTransformer, commandHandler, commandRequestParser);

        final SmscBoundMessageConsumer smscBoundMessageConsumer = new SmscBoundMessageConsumer(sessionManager);

//        MessageConsumerThread.registerConsumer(smscBoundMessageConsumer, telcoId, jedisPool, jsonTransformer.getGson());
    }

    @Override
    public void destroy() {
        try {
            logger.info("Shutting down Unirest...");
            Unirest.shutdown();
        } catch (IOException e) {
            logger.error("Error shutting down => ", e);
        }

    }
}