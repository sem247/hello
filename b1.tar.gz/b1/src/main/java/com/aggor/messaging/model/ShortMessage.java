package com.aggor.messaging.model;

import java.util.Set;

/**
 * @author semenu
 *
 */
public class ShortMessage {

	private String sender;
	private Set<String> recipient;
	private String message;

	public ShortMessage(final String sender, final Set<String> recipient, final String message) {
		this.sender = sender;
		this.recipient = recipient;
		this.message = message;
	}

	public String getSender() {
		return sender;
	}

	public Set<String> getRecipient() {
		return recipient;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		ShortMessage that = (ShortMessage) o;

		if (!sender.equals(that.sender)) return false;
		if (!recipient.equals(that.recipient)) return false;
		return message.equals(that.message);

	}

	@Override
	public int hashCode() {
		int result = sender.hashCode();
		result = 31 * result + recipient.hashCode();
		result = 31 * result + message.hashCode();
		return result;
	}

	@Override
	public String toString() {
		return "ShortMessage{" +
				"sender='" + sender + '\'' +
				", recipient=" + recipient +
				", message='" + message + '\'' +
				'}';
	}
}