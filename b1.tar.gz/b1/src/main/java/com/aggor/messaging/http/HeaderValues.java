package com.aggor.messaging.http;

/**
 * @author semenu
 *
 */
public interface HeaderValues {

	public static final String APPLICATION_JSON = "application/json";
	
}
