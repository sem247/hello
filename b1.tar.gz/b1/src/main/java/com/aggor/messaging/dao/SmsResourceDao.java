package com.aggor.messaging.dao;

import com.aggor.messaging.model.GenericMessage;
import org.slf4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.*;

import static java.util.Collections.unmodifiableList;
import static java.util.Collections.unmodifiableMap;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * @author semenu
 *
 */
public class SmsResourceDao {
    private final Logger logger = getLogger(SmsResourceDao.class);

	private JdbcTemplate jdbcTemplate;

	public SmsResourceDao(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public Integer saveMessage(GenericMessage message) {
        final String SCRIPT = "INSERT INTO short_message(sender, content, account_id, message_type, message_timestamp) VALUES(?, ?, ?, ?, ?)";
		Integer messageId = 0;

//		Connection connection = null;
//        PreparedStatement preparedStatement;
//
//        try {
//            System.out.println("About to store message in db => " + message);
//
//            connection = dataSource.getConnection();
//            preparedStatement = connection.prepareStatement(SCRIPT, RETURN_GENERATED_KEYS);
//
//            preparedStatement.setString(1, message.getSender());
//            if(message.getContent().isPresent()) {
//            	preparedStatement.setString(2, message.getContent().get());
//            } else {
//            	preparedStatement.setNull(2, Types.VARCHAR);
//            }
//            preparedStatement.setString(3, message.getAccountId());
//            preparedStatement.setString(4, message.getMessageType().name());
//            preparedStatement.setTimestamp(5, Timestamp.from(message.getMessageDateTime()));
//
//            preparedStatement.executeUpdate();
//
//            try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
//                if (generatedKeys.next()) {
//                	messageId = generatedKeys.getInt(1);
//                } else {
//                    logger.warn("Failed to save message to database. No message ID obtained.");
//                    System.out.println("Failed to save message to database. No message ID obtained.");
//                }
//                generatedKeys.close();
//            }
//
//            connection.close();
//        } catch (SQLException e) {
//            logger.error("Database error => ", e);
//            System.err.println("Database error => " + e);
//		} finally {
//            try {
//                if (connection != null) {
//                    connection.close();
//                }
//            } catch (SQLException e) {
//                logger.error("Database connection failed to close => ", e);
//                System.err.println("Database connection failed to close => " + e);
//            }
//        }

		return messageId;
	}

	public List<GenericMessage> fetchMessages(final String accountId, Optional<Integer> messageId, Optional<String> pageNumber) {
		List<GenericMessage> messages = new ArrayList<>();
//        Connection connection = null;
//        PreparedStatement preparedStatement;
//        try {
//            connection = dataSource.getConnection();
//
//            final String query = buildFetchQuery(messageId);
//
//            preparedStatement = connection.prepareStatement(query);
//
//            preparedStatement.setString(1, accountId);
//            if(messageId.isPresent()) {
//                preparedStatement.setInt(2, messageId.get());
//            }
//
//            try(ResultSet resultSet = preparedStatement.executeQuery()) {
//                while (resultSet.next()) {
//                    GenericMessage message = new GenericMessage(
//                            accountId,
//                            ofNullable(resultSet.getInt("id")),
//                            resultSet.getString("sender"),
//                            emptySet(),
//                            ofNullable(resultSet.getString("content")),
//                            MessageType.valueOf(resultSet.getString("message_type")),
//                            resultSet.getTimestamp("message_timestamp").toInstant(),
//                            emptyList()
//                    );
//
//                    messages.add(message);
//                }
//
//                resultSet.close();
//            }
//
//            connection.close();
//        } catch (SQLException e) {
//            logger.error("Database not available => ", e);
//        } finally {
//            try {
//                if (connection != null) {
//                    connection.close();
//                }
//            } catch (SQLException e) {
//                logger.error("Database connection failed to close => ", e);
//            }
//        }

		return unmodifiableList(messages);
	}

    private String buildFetchQuery(Optional<Integer> messageId) {
        StringBuilder queryBuilder = new StringBuilder()
                .append("SELECT id, sender, content, message_type, message_timestamp FROM short_message WHERE account_id = ?");
        if(messageId.isPresent()) {
            queryBuilder.append(" AND id = ?");
        }

        return queryBuilder.toString();
    }

    public Map<Integer, Set<String>> fetchMessageRecipients(List<Integer> messageIds) {
        Map<Integer, Set<String>> recipients = new HashMap<>();
//        Connection connection = null;
//        PreparedStatement preparedStatement;
//        try {
//            connection = dataSource.getConnection();
//
//            final String query = "SELECT DISTINCT recipient FROM short_message_recipient WHERE message_id = ?";
//
//            preparedStatement = connection.prepareStatement(query);
//
//            for (Integer id : messageIds) {
//                Set<String> phoneNumbers = new HashSet<>();
//
//                preparedStatement.setInt(1, id);
//
//                try (ResultSet resultSet = preparedStatement.executeQuery()) {
//
//                    while (resultSet.next()) {
//                        phoneNumbers.add(resultSet.getString("recipient"));
//                    }
//
//                    resultSet.close();
//                }
//
//                recipients.put(id, phoneNumbers);
//            }
//
//            connection.close();
//        } catch (SQLException e) {
//            logger.error("Database error => ", e);
//        } finally {
//            try {
//                if (connection != null) {
//                    connection.close();
//                }
//            } catch (SQLException e) {
//                logger.error("Database connection failed to close => ", e);
//            }
//        }

        return unmodifiableMap(recipients);
    }

}