package com.aggor.messaging.transport.smpp.model;

import com.cloudhopper.smpp.SmppSession;

import java.util.Optional;

/**
 * Created by semenu on 05/07/15.
 */
public class ConnectionResponse {
    private final Optional<SmppSession> session;
    private final Status status;

    public ConnectionResponse(Optional<SmppSession> session, Status status) {
        this.session = session;
        this.status = status;
    }

    public Optional<SmppSession> getSession() {
        return session;
    }

    public Status getStatus() {
        return status;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ConnectionResponse that = (ConnectionResponse) o;

        if (!session.equals(that.session)) return false;
        return status == that.status;

    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = session.hashCode();
        result = prime * result + status.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "ConnectionResponse{" +
                "session=" + session +
                ", status=" + status +
                '}';
    }
}