package com.aggor.messaging.supervisor

import spock.lang.Specification

/**
 * Created by semenu on 20/07/15.
 */
class EnquirelinkJobSpecification extends Specification {

/*
    def "should enquire link every 20 seconds"() {
        give: "I have a connection manager"

        def sessionManager = Mock(SessionManager)
        def enquireLikJob = new EnquireLinkJobAction(sessionManager)

        when: "I enquire link"

        enquireLikJob.doRun()

        then:
        1 * sessionManager.enquireLink()
    }
*/
}
