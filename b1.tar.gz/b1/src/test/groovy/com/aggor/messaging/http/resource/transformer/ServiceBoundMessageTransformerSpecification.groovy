package com.aggor.messaging.http.resource.transformer

import spock.lang.Specification

/**
 * Created by semenu on 21/03/15.
 */
class ServiceBoundMessageTransformerSpecification extends Specification {
}
