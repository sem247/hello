package com.aggor.messaging.transport.smpp

import com.aggor.messaging.http.client.RouterClient
import com.google.gson.Gson
import org.slf4j.Logger;

import com.aggor.messaging.service.SmscOriginatedMessageService;

import spock.lang.Specification


/**
 * @author semenu
 *
 */
class SmppConnectionMaker extends Specification {

	def "should connect to smsc"() {
		given: "valid connection credentials"
		def properties = new Properties()
		properties.setProperty("bind_type", "transceiver")
		properties.setProperty("connect_timeout", "10000")
		properties.setProperty("correlation_id", "default_test")
		properties.setProperty("enable_counters", "true")
		properties.setProperty("host", "127.0.0.1")
		properties.setProperty("log_bytes", "true")
		properties.setProperty("name", "TalkingDrums")
		properties.setProperty("password", "password")
		properties.setProperty("port", "2775")
		properties.setProperty("request_expiry_timeout", "30000")
		properties.setProperty("system_id", "smppclient1")
		properties.setProperty("window_monitor_interval", "15000")
		properties.setProperty("window_size", "1")
		
		def logger = Mock(Logger)

        def routerClient = new RouterClient("", new Gson(), logger)

		def incomingMessageService = new SmscOriginatedMessageService(routerClient, logger)
		def handler = new ClientSessionHandler("default_test", incomingMessageService, logger)
		
		def connection = new SessionConnection(SessionConfigurer.configure(properties), handler, logger)
				
		when: "I connect to the smsc"
		connection.connect()
		connection.disconnect()
		
		then:
		0 * logger.error(_,_)
	}
	
}