package com.aggor.collections;

import org.junit.Test;

import static java.util.Arrays.asList;

/**
 * Created by semenu on 23/06/15.
 */
public class CyclicListTest {

    @Test
    public void shouldRemoveNullItem() {
        final Person kofi = new Person("Kofi");
        final Person ama = new Person("Ama");
        final CyclicList<Person> personsCyclicList = new CyclicList<>(asList(kofi, ama));
    }

    class Person {
        private String name;

        public Person(String name) {
            this.name = name;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            Person person = (Person) o;

            return name.equals(person.name);

        }

        @Override
        public int hashCode() {
            return name.hashCode();
        }

        @Override
        public String toString() {
            return "Person{" +
                    "name='" + name + '\'' +
                    '}';
        }
    }
}