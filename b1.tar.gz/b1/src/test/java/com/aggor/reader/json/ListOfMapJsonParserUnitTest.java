package com.aggor.reader.json;

import com.google.common.collect.ImmutableMap;
import com.google.gson.Gson;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Created by semenu on 20/06/15.
 */
public class ListOfMapJsonParserUnitTest {
    private JsonFileReader jsonReader = new JsonFileReader();
    private Gson gson = new Gson();
    private ListOfMapJsonParser parser = new ListOfMapJsonParser(gson);

    @Test
    public void shouldBuildListOfMaps() {
        final String payload = jsonReader.readFile("payload/unit", "connections");
        final List<Map<String, String>> listObj = parser.parse(payload);

        final List<Map<String, String>> expected = Arrays.asList(
                new ImmutableMap.Builder<String, String>()
                        .put("bind_type", "transceiver")
                        .put("connect_timeout", "10000")
                        .put("enable_counters", "true")
                        .build(),
                new ImmutableMap.Builder<String, String>()
                        .put("bind_type", "transceiver")
                        .put("connect_timeout", "10000")
                        .put("enable_counters", "true")
                        .build()
        );

        assertThat(listObj, is(expected));
    }

}