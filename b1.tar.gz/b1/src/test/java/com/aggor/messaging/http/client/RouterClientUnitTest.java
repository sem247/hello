package com.aggor.messaging.http.client;

import com.aggor.messaging.http.server.RouterUnitMock;
import com.aggor.reader.json.JsonFileReader;
import com.aggor.reader.properties.PropertyLoader;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.google.common.collect.ImmutableMap;
import com.google.gson.Gson;
import com.mashape.unirest.http.HttpResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;

import java.util.Map;
import java.util.Properties;

import static com.github.tomakehurst.wiremock.client.WireMock.configureFor;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * @author semenu
 *
 */
public class RouterClientUnitTest extends BaseHttpClientUnitTest {
    private final JsonFileReader jsonReader = new JsonFileReader();

    private Gson gson = new Gson();

    private RouterUnitMock routerUnitMock = RouterUnitMock.getRouterUnitMock();

    private Properties properties = PropertyLoader.loadProperties("application.properties");

	private Logger logger;

	private WireMockServer wireMockServer;

	@Before
	public void setUp() {
        wireMockServer = new WireMockServer(5050);
        wireMockServer.start();

        configureFor("localhost", 5050);
	}

    @After
    public void tearDown() {
        wireMockServer.shutdown();
        super.tearDown();
    }

	@Test
	public void shouldPostSmsMessageToRouter() {
        final String payload = jsonReader.readFile("payload/unit", "mobile_originated_message");

        routerUnitMock.mockMobileOriginatedMessageResponse(payload, payload);

		RouterClient client = new RouterClient(properties.getProperty("routerbox.url"), gson);

        final Map<String, String> mobileOriginatedMessage = new ImmutableMap.Builder<String, String>()
                .put("sender", "0202001000")
                .put("recipient", "1234")
                .put("message", "Hello World!")
                .put("smsc", "default_test")
                .put("messageTime", "2015-03-16 13:03:21")
                .build();

		HttpResponse<String> jsonResoponse = client.postMessage(mobileOriginatedMessage);

		assertThat(jsonResoponse.getStatus(), is(201));
	}

}