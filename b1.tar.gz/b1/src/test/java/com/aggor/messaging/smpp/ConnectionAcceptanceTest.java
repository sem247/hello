package com.aggor.messaging.smpp;

import com.mashape.unirest.http.HttpResponse;
import org.junit.Test;

import static com.aggor.messaging.http.HeaderFields.CONTENT_TYPE;
import static com.aggor.messaging.http.HeaderValues.APPLICATION_JSON;
import static com.mashape.unirest.http.Unirest.post;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Created by semenu on 04/07/15.
 */
public class ConnectionAcceptanceTest {
    private final String gatewayUrl = "http://localhost:4567/api/gateway/connect";

    @Test
    public void shouldConnectAndDisconnectedToSmsc() throws Exception {
        final String connectCommand = "{\"command\":\"CONNECT\"}";
        final String disconnectCommand = "{\"command\":\"DISCONNECT\"}";

        HttpResponse<String> connectResponse = post(gatewayUrl)
                .header(CONTENT_TYPE, APPLICATION_JSON)
                .body(connectCommand)
                .asString();

        Thread.sleep(15000);

        HttpResponse<String> disconnectResponse = post(gatewayUrl)
                .header(CONTENT_TYPE, APPLICATION_JSON)
                .body(disconnectCommand)
                .asString();

        Thread.sleep(15000);

        assertThat(connectResponse.getStatus(), is(201));
        assertThat(disconnectResponse.getStatus(), is(201));
    }

    @Test
    public void shouldNotConnectASecondTimeIfAlreadyConnected() throws Exception {
        final String connectCommand = "{\"command\":\"CONNECT\"}";

        HttpResponse<String> connectResponse = post(gatewayUrl)
                .header(CONTENT_TYPE, APPLICATION_JSON)
                .body(connectCommand)
                .asString();

        Thread.sleep(15000);

        HttpResponse<String> connectResponse2 = post(gatewayUrl)
                .header(CONTENT_TYPE, APPLICATION_JSON)
                .body(connectCommand)
                .asString();

        Thread.sleep(15000);

        assertThat(connectResponse.getStatus(), is(201));
        assertThat(connectResponse2.getStatus(), is(201));
    }
}