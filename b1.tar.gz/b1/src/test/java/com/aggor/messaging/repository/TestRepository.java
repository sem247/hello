package com.aggor.messaging.repository;

import org.apache.commons.dbcp2.*;
import org.apache.commons.pool2.ObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.h2.tools.Server;
import org.slf4j.Logger;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import static org.h2.tools.Server.createTcpServer;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * @author semenu
 *
 */
public class TestRepository {
    private Server server;
    private DataSource dataSource;
    private LocalScriptRunner scriptRunner;

    private final Logger logger = getLogger(TestRepository.class);

    public TestRepository(LocalScriptRunner scriptRunner) {
		this.scriptRunner = scriptRunner;
    }

	public void startUp() throws SQLException {
        Properties properties = new Properties();
        properties.setProperty("driverClassName", "org.h2.Driver");

        dataSource = setupDataSource("jdbc:h2:mem:polling_db", properties);

        final String[] args = new String[] {"-tcpPort", "8092", "-tcpAllowOthers"};
        server = createTcpServer(args).start();

        Connection connection = null;
        try {
            connection = dataSource.getConnection();

            scriptRunner.executeScript(connection, "sql/db_schema.sql");

            connection.close();
        } catch (SQLException e) {
            logger.error("SQL error => ", e);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                logger.error("Cannot close connection => ", e);
            }
        }
    }

    private DataSource setupDataSource(String connectURI, Properties properties) {
        final ConnectionFactory connectionFactory = new DriverManagerConnectionFactory(connectURI, properties);
        PoolableConnectionFactory poolableConnectionFactory = new PoolableConnectionFactory(connectionFactory, null);
        final ObjectPool<PoolableConnection> connectionPool = new GenericObjectPool<>(poolableConnectionFactory);
        poolableConnectionFactory.setPool(connectionPool);

        return new PoolingDataSource<>(connectionPool);
    }

    public void shutdown() {
        server.stop();
        server.shutdown();
    }

	public DataSource getDataSource() {
		return dataSource;
	}

	public static void main(String[] args) throws Exception {
		LocalScriptRunner scriptRunner = new LocalScriptRunner();
		TestRepository repo = new TestRepository(scriptRunner);

		repo.startUp();

        TestDataDao testDataDao = new TestDataDao(repo.getDataSource(), scriptRunner);

        testDataDao.setUpTestData("test_data");

        repo.shutdown();
	}
}