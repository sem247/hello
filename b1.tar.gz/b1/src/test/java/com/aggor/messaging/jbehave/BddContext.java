package com.aggor.messaging.jbehave;

import com.aggor.reader.json.JsonFileReader;
import com.mashape.unirest.http.HttpResponse;

/**
 * Created by semenu on 25/03/15.
 */
public class BddContext {
    private static BddContext context;
    private JsonFileReader jsonReader = new JsonFileReader();
    private String payload;
    private HttpResponse<String> jsonResponse;

    private Integer statusCode;

    private BddContext() { }

    public static BddContext getContext() {
        if(context == null) {
            context = new BddContext();
        }

        return context;
    }

    public void setPayload(final String fileName) {
        payload = jsonReader.readFile("payload/bdd", fileName);
    }

    public String getPayload() {
        return payload;
    }

    public void setResponse(HttpResponse<String> response) {
        this.jsonResponse = response;
    }

    public Integer getStatusCode() {
        return jsonResponse.getStatus();
    }
}
