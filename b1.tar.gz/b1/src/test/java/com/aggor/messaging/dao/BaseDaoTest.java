package com.aggor.messaging.dao;

import com.aggor.messaging.dao.config.ApplicationConfig;
import com.aggor.messaging.dao.config.DataSourceConfig;
import com.aggor.messaging.repository.LocalScriptRunner;
import com.aggor.messaging.repository.TestRepository;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Created by semenu on 09/06/16.
 */
public class BaseDaoTest {
    protected final LocalScriptRunner scriptRunner = new LocalScriptRunner();
    protected final TestRepository testRepository = new TestRepository(scriptRunner);

    protected final ApplicationContext applicationContext = new AnnotationConfigApplicationContext(
            DataSourceConfig.class,
            ApplicationConfig.class
    );

}