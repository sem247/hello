package com.aggor.messaging.http.server;

import com.github.tomakehurst.wiremock.client.ValueMatchingStrategy;

import static com.github.tomakehurst.wiremock.client.WireMock.*;

/**
 * @author semenu
 *
 */
public class RouterUnitMock {
    private static RouterUnitMock instance;

    private final String mockBlueUrl = "/mo-sms";

    private RouterUnitMock() {
    }

    public static RouterUnitMock getRouterUnitMock() {
        if (instance == null) {
            instance = new RouterUnitMock();
        }

        return instance;
    }

    public void mockMobileOriginatedMessageResponse(String messageRequest, String messageResponse) {
        ValueMatchingStrategy bodyMatcher = new ValueMatchingStrategy();
        bodyMatcher.setEqualToJson(messageRequest);

        stubFor(post(urlMatching(mockBlueUrl))
                .withHeader("Content-Type", equalTo("application/json"))
                .withRequestBody(bodyMatcher)
                .willReturn(aResponse()
                        .withStatus(201)
                        .withHeader("Content-Type", "application/json")
                        .withBody(messageResponse)));
    }

    public void mockBadRequest() {
        stubFor(post(urlMatching(mockBlueUrl))
                        .withHeader("Content-Type", equalTo("application/json"))
                        .willReturn(aResponse()
                                .withStatus(400))
        );
    }

    public void mockInternalServerError() {
        stubFor(post(urlMatching(mockBlueUrl))
                        .withHeader("Content-Type", equalTo("application/json"))
                        .willReturn(aResponse()
                                .withStatus(500))
        );
    }

}