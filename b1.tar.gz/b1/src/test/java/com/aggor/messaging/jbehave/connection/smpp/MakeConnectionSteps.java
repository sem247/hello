package com.aggor.messaging.jbehave.connection.smpp;

import com.mashape.unirest.http.exceptions.UnirestException;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Pending;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import static com.aggor.messaging.http.HeaderFields.CONTENT_TYPE;
import static com.aggor.messaging.http.HeaderValues.APPLICATION_JSON;
import static com.aggor.messaging.jbehave.BddContext.getContext;
import static com.mashape.unirest.http.Unirest.post;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class MakeConnectionSteps {
    private final String baseUrl = "http://localhost";

    @Given("I have an account with a telco")
    @Pending
    public void givenIHaveAnAccountWithATelco() {
        getContext().setPayload("smpp_connect_command");
    }

    @Given("I have accounts with multiple telcos")
    @Pending
    public void givenIHaveAccountsWithMultipleTelcos() throws UnirestException {
        getContext().setResponse(post(baseUrl + "/command")
                .header(CONTENT_TYPE, APPLICATION_JSON)
                .body(getContext().getPayload())
                .asString());
    }

    @When("I elect to connect")
    @Pending
    public void whenIConnect() {
        assertThat(getContext().getStatusCode(), is(200));
    }

    @When("I elect to connect to all")
    @Pending
    public void whenIElectToConnectToAll() {
        //TODO
    }

    @Then("I should be connected to the SMPP gateway of the telco")
    @Pending
    public void thenIShouldBeConnectedToTheSMPPGatewayOfTheTelco() {
        //TODO
    }

    @Then("I should be connected to the SMPP gateway of each telco")
    @Pending
    public void thenIShouldBeConnectedToTheSMPPGatewayOfEachTelco() {
        //TODO
    }

}