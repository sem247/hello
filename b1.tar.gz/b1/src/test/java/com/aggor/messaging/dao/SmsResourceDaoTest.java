package com.aggor.messaging.dao;

import com.aggor.messaging.model.GenericMessage;
import com.aggor.messaging.repository.TestDataDao;
import com.aggor.messaging.time.GmtFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static java.util.Arrays.asList;
import static java.util.Collections.emptySet;
import static java.util.Collections.singleton;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * @author semenu
 */

public class SmsResourceDaoTest extends BaseDaoTest {
	private final SmsResourceDao smsResourceDao = (SmsResourceDao)applicationContext.getBean("smsResourceDao");

	private final String accountId = "123-ABC";

	@Before
	public void setUp() throws Exception {
        testRepository.startUp();

        final TestDataDao testDataDao = new TestDataDao(testRepository.getDataSource(), scriptRunner);
        testDataDao.setUpTestData("sms_test_data");
    }

	@After
	public void tearDown() throws Exception {
        testRepository.shutdown();
	}

	@Test
	public void shouldSaveSoMessage() throws Exception {
		final GenericMessage outboundMessage = new GenericMessage(
                accountId,
				of(1),
				"1234",
                singleton("0201234567"),
				of("A power greater than ourselves can restore us to sanity"),
                GmtFactory.toInstant("2015-02-01 11:15:02")
        );

        final Integer messageId = smsResourceDao.saveMessage(outboundMessage);

		assertThat(messageId, is(1));
	}

    @Test
    public void shouldSaveMoMessage() throws Exception {
        final GenericMessage message = new GenericMessage(
                accountId,
                empty(),
                "0201127485",
                singleton("1234"),
                of("Why are you here? To cut the head of a snake!"),
                Instant.now()
        );

        Integer messageId = smsResourceDao.saveMessage(message);

        assertThat(messageId, is(1));
    }

    @Test
    public void shouldGetAccountMessages() throws Exception {
        final List<GenericMessage> messages = smsResourceDao.fetchMessages(accountId, empty(), empty());

        final GenericMessage em1 = new GenericMessage(
                accountId,
                of(1),
                "1234",
                emptySet(),
//                asList("0201234567"),
                of("A power greater than ourselves can restore us to sanity"),
                GmtFactory.toInstant("2015-02-01 11:15:02")
        );
        final GenericMessage em2 = new GenericMessage(
                accountId,
                of(2),
                "1234",
                emptySet(),
//                asList("0269878854", "0501124725", "0332514420"),
                of("You can see my face. Wear a mask!"),
                GmtFactory.toInstant("2015-02-08 19:33:48")
        );
        final GenericMessage em3 = new GenericMessage(
                accountId,
                of(3),
                "0122345534",
                emptySet(),
//                asList("1234"),
                of("Tell them everything you told me about the man, nothing about the girl"),
                GmtFactory.toInstant("2015-02-04 08:55:17")
        );
        final GenericMessage em4 = new GenericMessage(
                accountId,
                of(4),
                "0500127477",
                emptySet(),
//                asList("1234"),
                of("We do not have anything other than what you have just told us"),
                GmtFactory.toInstant("2015-02-04 10:33:19")
        );

        assertThat(messages, hasItems(em1, em2, em3, em4));
    }

    @Test
    public void shouldGetIdentifiedMessageForAccount() throws Exception {
        final List<GenericMessage> messages = smsResourceDao.fetchMessages(accountId, of(2), empty());

        final GenericMessage em2 = new GenericMessage(
                accountId,
                of(2),
                "1234",
                emptySet(),
//                asList("0269878854", "0501124725", "0332514420"),
                of("You can see my face. Wear a mask!"),
                GmtFactory.toInstant("2015-02-08 19:33:48")
        );

        assertThat(messages.size(), is(1));
        assertThat(messages, hasItems(em2));
    }

    @Test
    public void shouldGetMessageRecipients() {
        final Map<Integer, Set<String>> recipients = smsResourceDao.fetchMessageRecipients(asList(1, 2, 3, 4));

        assertThat(recipients.size(), is(4));
        assertThat(recipients.get(1), hasItems("0201234567"));
        assertThat(recipients.get(2), hasItems("0269878854", "0501124725", "0332514420"));
        assertThat(recipients.get(3), hasItems("1234"));
        assertThat(recipients.get(4), hasItems("1234"));
    }

}