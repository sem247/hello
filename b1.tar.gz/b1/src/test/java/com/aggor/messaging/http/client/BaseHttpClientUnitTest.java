package com.aggor.messaging.http.client;

import com.mashape.unirest.http.Unirest;
import org.junit.After;

import java.io.IOException;

/**
 * Created by semenu on 06/06/16.
 */
public abstract class BaseHttpClientUnitTest {
    @After
    public void tearDown() {
        try {
            Unirest.shutdown();
        } catch (IOException e) {
            // Do nothing
        }
    }
}