package com.aggor.messaging.jbehave;

import net.thucydides.jbehave.ThucydidesJUnitStories;

/**
 * @author semenu
 *
 */
public class RegressionTestsRunner extends ThucydidesJUnitStories {

}
