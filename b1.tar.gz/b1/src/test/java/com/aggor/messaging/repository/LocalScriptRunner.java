package com.aggor.messaging.repository;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;

import static java.lang.Thread.currentThread;
import static org.h2.tools.RunScript.execute;

/**
 * @author semenu
 *
 */
public class LocalScriptRunner {

    public void executeScript(final Connection connection, final String scriptFile) throws SQLException {
        final InputStream inputStream = currentThread().getContextClassLoader().getResourceAsStream(scriptFile);
        execute(connection, new InputStreamReader(inputStream));
    }

}
