package com.aggor.messaging.repository;

import org.slf4j.Logger;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * @author semenu
 *
 */
public class TestDataDao {
    private DataSource dataSource;
    private LocalScriptRunner scriptRunner;
    private final Logger logger = getLogger(TestDataDao.class);

    public TestDataDao(DataSource dataSource, LocalScriptRunner scriptRunner) {
        this.dataSource = dataSource;
        this.scriptRunner = scriptRunner;
    }

    public void setUpTestData(final String scriptFile) {
        Connection connection = null;

        try {
            connection = dataSource.getConnection();

            scriptRunner.executeScript(connection, "sql/"+scriptFile+".sql");

            connection.close();
        } catch (SQLException e) {
            logger.error("Database error => ", e);
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                logger.error("Database connection failed to close => ", e);
            }
        }
    }

}