DROP TABLE IF EXISTS short_message_recipient;
DROP TABLE IF EXISTS short_message;

CREATE TABLE short_message(
	id INT NOT NULL PRIMARY KEY auto_increment,
	sender VARCHAR(30),
	content VARCHAR(255),
	account_id VARCHAR(255),
	message_type VARCHAR(50),
	message_timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
	PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS short_message_recipient(
	recipient VARCHAR(30) NOT NULL,
	message_id INT NOT NULL,
	status_timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
	status VARCHAR(50)
);
-- 
-- CREATE TABLE IF NOT EXISTS ShortMessageMeta(
-- 	COL1 INTEGER NOT NULL,
-- 	COL2 CHAR(25),
-- 	COL3 VARCHAR(25) NOT NULL,
-- 	COL4 DATE,
-- 	PRIMARY KEY (COL1)
-- )
-- 