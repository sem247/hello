DELETE FROM short_message;
DELETE FROM short_message_recipient;

INSERT INTO short_message(id, sender, content, account_id, message_type, message_timestamp) VALUES
(1, '1234', 'A power greater than ourselves can restore us to sanity', '123-ABC', 'SERVICE_ORIGINATED', '2015-02-01 11:15:02'),
(2, '1234', 'You can see my face. Wear a mask!', '123-ABC', 'SERVICE_ORIGINATED', '2015-02-08 19:33:48'),
(3, '0122345534', 'Tell them everything you told me about the man, nothing about the girl', '123-ABC', 'MOBILE_ORIGINATED', '2015-02-04 08:55:17'),
(4, '0500127477', 'We do not have anything other than what you have just told us', '123-ABC', 'MOBILE_ORIGINATED', '2015-02-04 10:33:19'),
(5, '4412', 'Hello, are you there? I am here minister', 'QWW-ABC', 'SERVICE_ORIGINATED', '2015-02-01 11:15:02');

INSERT INTO short_message_recipient(recipient, message_id, status_timestamp, status) VALUES
('0201234567', 1, '2015-02-01 11:15:02', 'MESSAGE_DRAFT'),
('0201234567', 1, '2015-02-01 11:19:22', 'MESSAGE_INQUEUE'),
('0201234567', 1, '2015-02-01 11:20:41', 'MESSAGE_SENT'),
('0269878854', 2, '2015-02-08 19:33:48', 'MESSAGE_DRAFT'),
('0269878854', 2, '2015-02-08 19:35:07', 'MESSAGE_INQUEUE'),
('0501124725', 2, '2015-02-08 19:33:48', 'MESSAGE_DRAFT'),
('0501124725', 2, '2015-02-08 19:35:07', 'MESSAGE_INQUEUE'),
('0332514420', 2, '2015-02-08 19:33:48', 'MESSAGE_DRAFT'),
('0332514420', 2, '2015-02-08 19:35:07', 'MESSAGE_INQUEUE'),
('1234', 3, '2015-02-04 08:55:17', 'MESSAGE_MO'),
('1234', 4, '2015-02-04 10:33:19', 'MESSAGE_MO'),
('0114114754', 5, '2015-02-01 11:15:02', 'MESSAGE_DRAFT'),
('0114114754', 5, '2015-02-01 11:19:22', 'MESSAGE_INQUEUE'),
('0114114754', 5, '2015-02-01 11:20:41', 'MESSAGE_SENT');